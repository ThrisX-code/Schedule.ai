/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Task } from './types';
import { TaskForm } from './components/TaskForm';
import { Timeline } from './components/Timeline';
import { PromptOrchestrator } from './components/PromptOrchestrator';
import { Metrics } from './components/Metrics';

export default function App() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null);

  const handleAddTask = (newTaskData: Omit<Task, 'id' | 'completed' | 'createdAt'>) => {
    const newTask: Task = {
      ...newTaskData,
      id: crypto.randomUUID(),
      completed: false,
      createdAt: Date.now(),
    };
    setTasks(prev => [newTask, ...prev]);
  };

  const handleToggleComplete = (id: string) => {
    setTasks(prev => prev.map(task => 
      task.id === id ? { ...task, completed: !task.completed } : task
    ));
  };

  const handleDelete = (id: string) => {
    setTasks(prev => prev.filter(task => task.id !== id));
    if (selectedTaskId === id) {
      setSelectedTaskId(null);
    }
  };

  const selectedTask = tasks.find(t => t.id === selectedTaskId) || null;

  const formattedDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  }).toUpperCase();

  return (
    <div className="min-h-screen lg:h-screen lg:min-h-[700px] w-full p-4 md:p-6 flex flex-col gap-4 selection:bg-indigo-500/30">
      {/* Header */}
      <header className="flex flex-col md:flex-row justify-between md:items-end pb-2 border-b border-slate-800 shrink-0 gap-4 md:gap-0">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-indigo-600 uppercase">
            AI CO-PILOT NEXUS
          </h1>
          <p className="text-xs text-slate-500 uppercase tracking-widest font-bold">System Status: Optimal // Core v4.2</p>
        </div>
        <div className="text-right">
          <p className="text-lg font-mono text-indigo-400">{formattedDate}</p>
          <p className="text-xs text-slate-500 text-center">SESSION_ID: 8x-992-ALPHA</p>
        </div>
      </header>

      {/* Main Bento Grid */}
      <div className="flex-1 grid grid-cols-1 md:grid-cols-12 gap-4 md:min-h-0">
        
        {/* Task Creation Form */}
        <div className="md:col-span-3 bento-card md:min-h-0">
          <TaskForm onAdd={handleAddTask} />
        </div>

        {/* Sprint Timeline View */}
        <div className="md:col-span-5 bento-card overflow-hidden md:min-h-0">
          <h2 className="text-sm font-bold text-slate-400 uppercase mb-4 shrink-0">Active Sprint Pipeline</h2>
          <Timeline 
            tasks={tasks}
            selectedTaskId={selectedTaskId}
            onSelectTask={setSelectedTaskId}
            onToggleComplete={handleToggleComplete}
            onDelete={handleDelete}
          />
        </div>

        {/* AI Prompt Orchestrator Panel */}
        <div className="md:col-span-4 bento-card flex flex-col md:min-h-0">
          <PromptOrchestrator task={selectedTask} />
        </div>
      </div>

      {/* Metrics Widget */}
      <div className="flex space-x-4 shrink-0 overflow-x-auto scrollbar-hide pb-2 -mb-2">
        <div className="flex-1 bento-card flex-row items-center justify-between px-6 md:px-8 py-4 md:py-0 min-h-[4rem] h-[164px] gap-8 md:gap-0 w-max md:w-auto">
          <Metrics tasks={tasks} />
        </div>
      </div>
    </div>
  );
}
