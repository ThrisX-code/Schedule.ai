import React, { useState } from 'react';
import { Task } from '../types';

interface PromptOrchestratorProps {
  task: Task | null;
}

export function PromptOrchestrator({ task }: PromptOrchestratorProps) {
  const [copied, setCopied] = useState(false);

  const promptText = task ? `Act as an elite technical co-pilot. I am currently running a ${task.duration}-minute sprint for the task: '${task.name}' under the ${task.category} track. My current core focus or roadblock is: '${task.context}'. Please break this down into a laser-focused micro-roadmap, provide the primary logical architecture, and warn me about common edge-case errors to avoid.` : '';

  const handleCopy = async () => {
    if (!task) return;
    try {
      await navigator.clipboard.writeText(promptText);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch (err) {
      console.error('Failed to copy text', err);
    }
  };

  return (
    <>
      <div className="flex justify-between items-center mb-4 shrink-0">
        <h2 className="text-sm font-bold text-indigo-400 uppercase tracking-wider">AI Orchestrator</h2>
        <button 
          onClick={handleCopy}
          disabled={!task}
          className={`text-[10px] px-3 py-1 rounded border transition-colors uppercase font-bold
            ${copied 
              ? 'bg-slate-800 border-slate-700 text-emerald-400' 
              : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-200 disabled:opacity-50 disabled:hover:bg-slate-800'
            }`}
        >
          {copied ? 'Copied!' : 'Copy to Clipboard'}
        </button>
      </div>
      
      <div className="flex-1 h-[267px] bg-slate-950/50 border border-slate-800 rounded-lg p-4 font-mono text-xs leading-relaxed text-slate-300 md:overflow-y-auto scrollbar-hide min-h-0">
        {!task ? (
          <p className="opacity-40 italic">Select a task from the timeline to generate the AI micro-roadmap prompt...</p>
        ) : (
          <>
            <span className="text-indigo-400 font-bold mb-2 block">PROMPT_LOADED:</span>
            {promptText}
          </>
        )}
      </div>
      
      <div className="mt-4 pt-4 border-t border-slate-800 shrink-0">
        <p className="text-[10px] text-slate-500 uppercase tracking-widest leading-none mb-1 text-center">Model Engine</p>
        <p className="text-xs font-bold text-slate-400 text-center">GPT-4o-TURBO / NEURAL-CORE-9</p>
      </div>
    </>
  );
}
